The structure of the files is as follows: 

param N:= Number of nodes																																																			
param M:= Number of depots																																																			
param Qmax:= Sum of total demands
																																																																																																		
param d:= Demand of nodes + final fictitious node with zero demand																																																																																																																																																								
param k:= Number of available vehicles per depot																																																																																																																																																						
set R[k]:= Set of vehicles for each k-th depot																																																																																																
param w:= Hiring cost per vehicle																																																					
param Q:= Capacity per vehicle																																							
param γ:= A binary parameter linking the potential production facilities to nodes(Self-supply)																																																						
param D:= Matrix of distance between depots and nodes
param C:= Matrix of distance between nodes																																																					